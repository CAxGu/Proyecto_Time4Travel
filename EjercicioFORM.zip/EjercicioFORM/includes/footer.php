<div id="footer">
	Visita <a href="http://www.webdesign.com" target="_blank">WebDesign</a> para aprender diseño
</div>