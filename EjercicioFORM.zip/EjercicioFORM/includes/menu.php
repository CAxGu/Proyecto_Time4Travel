<div id="menu">
	<a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;  
	<a href="index.php?page=controller_users">Usuarios</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="index.php?page=services">Servicios</a>&nbsp;&nbsp;|&nbsp;&nbsp;
	<a href="index.php?page=aboutus">About Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="index.php?page=contactus">Contact Us</a>
</div>