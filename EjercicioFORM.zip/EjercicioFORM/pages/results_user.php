<?php

	include("utils/functions.inc.php");

	$user = $_SESSION['user'];
	debug($user);
	echo $_SESSION['msje'];
